
import path from 'path';
const mainModulePath = path.join(__dirname, 'linux', 'linux-agent.ts');
import { LinuxAgent as AgentClass } from mainModulePath;
const { AgentConfig, loadConfig } = require('./common/agent-config');

// Para ser autosuficiente, exportamos las clases necesarias
exports.LinuxAgent = AgentClass;
exports.AgentConfig = AgentConfig;
exports.loadConfig = loadConfig;
