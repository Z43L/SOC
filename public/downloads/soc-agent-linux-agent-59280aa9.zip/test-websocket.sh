#!/bin/bash
echo "Testing WebSocket connection to SOC server..."
echo "Server URL: https://soc-test.example.com"
echo "Agent ID: agent-59280aa9"

# Simple test using curl to check if server is reachable
echo "Checking if server is reachable..."
if ! curl -s --max-time 10 "https://soc-test.example.com/api/health" >/dev/null 2>&1; then
    echo "ERROR: Cannot reach SOC server at https://soc-test.example.com"
    echo "Please check:"
    echo "1. Server URL is correct"
    echo "2. Network connectivity"
    echo "3. Firewall settings"
    exit 1
fi

echo ""
echo "Server is reachable!"
echo "Next steps:"
echo "1. Run 'sudo ./install.sh' to install the agent"
echo "2. The agent will automatically connect using WebSocket"
echo "3. Check the SOC dashboard to verify agent connection"
echo ""
