#!/bin/bash
# Instalador del Agente SOC-Inteligente para macOS
# ----------------------------------------------
# Este script instala y configura el agente de monitoreo de seguridad
# para conectarlo con la plataforma SOC-Inteligente.

set -e

# Comprobar permisos de superusuario
if [ "$(id -u)" -ne 0 ]; then
  echo "Este script debe ejecutarse como superusuario (sudo)."
  exit 1
fi

# Crear directorios necesarios
INSTALL_DIR="/Library/SOCIntelligent"
CONFIG_DIR="/Library/Application Support/SOCIntelligent"
LOG_DIR="/Library/Logs/SOCIntelligent"

mkdir -p "$INSTALL_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$LOG_DIR"
chmod 755 "$INSTALL_DIR"
chmod 755 "$CONFIG_DIR" 
chmod 755 "$LOG_DIR"

# Copiar archivos
echo "Instalando archivos del agente..."
cp -Rf ./agent/* "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/agent-macos"

# Guardar configuración
echo "Configurando agente..."
CONFIG_PATH="$CONFIG_DIR/agent-config.json"
echo '{"serverUrl":"https://b7b3c905-a6e5-4d27-afc6-8f883b2e2251-00-3vyl34gdu6eps.spock.replit.dev","registrationKey":"000001-33f0b8080b421883-sucwt3-56fe","agentId":"agent-a946d8cd","configPath":"/Library/Application Support/SOCIntelligent/agent-config.json","heartbeatInterval":60,"dataUploadInterval":300,"scanInterval":3600,"registrationEndpoint":"/api/agents/register","dataEndpoint":"/api/agents/data","heartbeatEndpoint":"/api/agents/heartbeat","signMessages":false,"capabilities":{"fileSystemMonitoring":true,"processMonitoring":true,"networkMonitoring":true,"registryMonitoring":false,"securityLogsMonitoring":true,"malwareScanning":true,"vulnerabilityScanning":true},"logFilePath":"/Library/Logs/SOCIntelligent/agent.log","maxStorageSize":100,"logLevel":"info"}' > "$CONFIG_PATH"
chmod 644 "$CONFIG_PATH"

# Crear archivo de LaunchDaemon
PLIST_PATH="/Library/LaunchDaemons/com.soc-intelligent.agent.plist"
cat > "$PLIST_PATH" << EOL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.soc-intelligent.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>$INSTALL_DIR/agent-macos</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$LOG_DIR/agent.log</string>
    <key>StandardErrorPath</key>
    <string>$LOG_DIR/agent-error.log</string>
    <key>WorkingDirectory</key>
    <string>$INSTALL_DIR</string>
</dict>
</plist>
EOL

# Establecer permisos correctos
chmod 644 "$PLIST_PATH"
chown root:wheel "$PLIST_PATH"

# Iniciar el servicio
echo "Iniciando agente SOC-Intelligent..."
launchctl load -w "$PLIST_PATH"

echo "Instalación completada. El agente está en ejecución."
echo "ID del Agente: agent-a946d8cd"
echo "Servidor SOC: https://b7b3c905-a6e5-4d27-afc6-8f883b2e2251-00-3vyl34gdu6eps.spock.replit.dev"
