
const path = require('path');
const mainModulePath = path.join(__dirname, 'macos', 'macos-agent.ts');
const AgentClass = require(mainModulePath)['MacOSAgent'];
const { AgentConfig, loadConfig } = require('./common/agent-config');

// Para ser autosuficiente, exportamos las clases necesarias
exports.MacOSAgent = AgentClass;
exports.AgentConfig = AgentConfig;
exports.loadConfig = loadConfig;
