# SOC Intelligent Agent - MACOS

## Overview
This package contains the SOC Intelligent Agent for macos systems, pre-configured to connect to your SOC platform.

## Contents
- **Agent Binary**: The main agent executable
- **Configuration**: Pre-configured agent-config.json
- **Installation Script**: Automated installation and service setup
- **Uninstall Script**: Clean removal of the agent
- **WebSocket Test**: Connection verification script

## Agent Configuration
- **Server URL**: https://soc-test.example.com
- **Agent ID**: agent-ca7c434f
- **Registration Key**: [Embedded securely]

## Quick Installation

### Linux/macOS

1. **Make executable**: chmod +x install.sh
2. **Run installer**: sudo ./install.sh
3. **Verify installation**: systemctl status soc-intelligent-agent
4. **Test connection**: ./test-websocket.sh

### Manual Installation Steps:
1. Copy agent binary to /opt/soc-intelligent/
2. Copy agent-config.json to /etc/soc-intelligent/
3. Set up systemd service (install.sh does this automatically)
4. Start and enable the service

### Requirements:
- Linux distribution with systemd, Upstart, or SysV init
- Root/sudo privileges for installation
- Network access to https://soc-test.example.com


## Verification
After installation, verify the agent is working:

1. **Service Status**: Check that the agent service is running
   - Linux/macOS: systemctl status soc-intelligent-agent

2. **Log Files**: Check for any errors in the logs
   - Location: /var/log/soc-intelligent/agent.log

3. **SOC Dashboard**: The agent should appear as "online" in your SOC dashboard within 60 seconds

4. **Connection Test**: Run the test-websocket script to verify connectivity

## Capabilities
This agent is configured with the following monitoring capabilities:
- fileSystemMonitoring: Enabled
- processMonitoring: Enabled
- networkMonitoring: Enabled
- registryMonitoring: Disabled
- securityLogsMonitoring: Enabled
- malwareScanning: Enabled
- vulnerabilityScanning: Enabled

## Troubleshooting

### Agent Not Connecting
1. Verify network connectivity to https://soc-test.example.com
2. Check firewall settings (agent needs outbound HTTPS access)
3. Verify agent-config.json has correct server URL and credentials
4. Check agent logs for specific error messages

### Service Won't Start
1. Check service logs: journalctl -u soc-intelligent-agent
2. Verify binary permissions: chmod +x soc-agent-linux
3. Check configuration file permissions
4. Try running manually: ./soc-agent-linux

### Permission Issues
- Ensure installation was run with appropriate privileges
- Linux/macOS: Use sudo

## Uninstallation
To remove the agent:
- Run sudo ./uninstall.sh

## Support
For technical support, contact your SOC administrator or refer to the documentation at https://soc-test.example.com/docs

---
Generated on: 2025-06-06T17:45:13.621Z
Agent Version: 1.0.0
Package ID: agent-ca7c434f
